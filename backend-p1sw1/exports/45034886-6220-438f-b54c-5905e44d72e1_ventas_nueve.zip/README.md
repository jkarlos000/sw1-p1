# Flutter Mockup Project

This Flutter app was generated from visual mockups using AI interpretation.

## Getting Started

### Prerequisites
- Flutter SDK (>= 3.0.0)
- Dart SDK (included with Flutter)
- Android Studio / Xcode (for mobile development)

### Installation

1. Get dependencies:
```bash
flutter pub get
```

2. Run the app:
```bash
flutter run
```

## Screens

- **Cliente**: 8 components
- **Venta**: 10 components
- **DetalleVenta**: 7 components
- **Articulo**: 10 components
- **Empleado**: 8 components

## Generated Code

This project was generated automatically. The following structure is used:

```
lib/
├── main.dart
├── theme/
│   └── app_theme.dart
└── screens/
    └── cliente.dart
    └── venta.dart
    └── detalle_venta.dart
    └── articulo.dart
    └── empleado.dart
```

## Customization

You can customize this app by:
- Editing screen files in `lib/screens/`
- Modifying theme in `lib/theme/app_theme.dart`
- Adding business logic to state classes
- Implementing navigation between screens

## Support

For more information, visit [Flutter Documentation](https://flutter.dev/docs)
