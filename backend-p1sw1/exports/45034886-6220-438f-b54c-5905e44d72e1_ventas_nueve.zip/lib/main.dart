import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/cliente.dart';
import 'screens/venta.dart';
import 'screens/detalle_venta.dart';
import 'screens/articulo.dart';
import 'screens/empleado.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Mockup',
      theme: AppTheme.lightTheme,
      home: const Cliente(),
      routes: {
        '/cliente': (context) => const Cliente(),
        '/venta': (context) => const Venta(),
        '/detalle-venta': (context) => const DetalleVenta(),
        '/articulo': (context) => const Articulo(),
        '/empleado': (context) => const Empleado(),
      },
    );
  }
}
