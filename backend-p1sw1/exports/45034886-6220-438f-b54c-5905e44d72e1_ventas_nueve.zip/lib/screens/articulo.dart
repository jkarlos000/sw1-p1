import 'package:flutter/material.dart';

class ArticuloScreen extends StatelessWidget {

  final int id;
  final String nombre;
  final String descripcion;
  final double precio;
  final int stock;
  final String categoria;

  final TextEditingController nombreController = TextEditingController();
  final TextEditingController descripcionController = TextEditingController();
  final TextEditingController categoriaController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Articulo'),
        backgroundColor: Color(0xFF2196F3),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: nombreController,
              decoration: InputDecoration(
                labelText: 'Nombre',
                hintText: 'Ingrese nombre (String)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: descripcionController,
              decoration: InputDecoration(
                labelText: 'Descripcion',
                hintText: 'Ingrese descripcion (String)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: categoriaController,
              decoration: InputDecoration(
                labelText: 'Categoria',
                hintText: 'Ingrese categoria (String)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('id (int)'),
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('precio (double)'),
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('stock (int)'),
            ),
            SizedBox(height: 16),
            TextField(
              controller: idController,
              decoration: InputDecoration(
                labelText: 'Id',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: nombreController,
              decoration: InputDecoration(
                labelText: 'Nombre',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: descripcionController,
              decoration: InputDecoration(
                labelText: 'Descripcion',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: precioController,
              decoration: InputDecoration(
                labelText: 'Precio',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: stockController,
              decoration: InputDecoration(
                labelText: 'Stock',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: categoriaController,
              decoration: InputDecoration(
                labelText: 'Categoria',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: actualizarPrecio,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('ACTUALIZARPRECIO', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: actualizarStock,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('ACTUALIZARSTOCK', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: estaDisponible,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('ESTADISPONIBLE', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: validarStock,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('VALIDARSTOCK', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16)
          ],
        ),
      ),
    );
  }


  void actualizarPrecio(double nuevoPrecio) {
    // TODO: Implementar actualizarPrecio
    print('actualizarPrecio ejecutado');
  }

  void actualizarStock(int cantidad) {
    // TODO: Implementar actualizarStock
    print('actualizarStock ejecutado');
  }

  bool estaDisponible(int cantidad) {
    // TODO: Implementar estaDisponible
    print('estaDisponible ejecutado');
  }

  bool validarStock(int cantidad) {
    // TODO: Implementar validarStock
    print('validarStock ejecutado');
  }

}
