import 'package:flutter/material.dart';

class ClienteScreen extends StatelessWidget {

  final int id;
  final String nombre;
  final String telefono;
  final String email;
  final String direccion;

  final TextEditingController nombreController = TextEditingController();
  final TextEditingController telefonoController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController direccionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cliente'),
        backgroundColor: Color(0xFF2196F3),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: nombreController,
              decoration: InputDecoration(
                labelText: 'Nombre',
                hintText: 'Ingrese nombre (String)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: telefonoController,
              decoration: InputDecoration(
                labelText: 'Telefono',
                hintText: 'Ingrese telefono (String)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                labelText: 'Email',
                hintText: 'Ingrese email (String)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: direccionController,
              decoration: InputDecoration(
                labelText: 'Direccion',
                hintText: 'Ingrese direccion (String)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('id (int)'),
            ),
            SizedBox(height: 16),
            TextField(
              controller: idController,
              decoration: InputDecoration(
                labelText: 'Id',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: nombreController,
              decoration: InputDecoration(
                labelText: 'Nombre',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: telefonoController,
              decoration: InputDecoration(
                labelText: 'Telefono',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: direccionController,
              decoration: InputDecoration(
                labelText: 'Direccion',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: validarEmail,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('VALIDAREMAIL', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: actualizarDatos,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('ACTUALIZARDATOS', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: obtenerHistorialCompras,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('OBTENERHISTORIALCOMPRAS', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16)
          ],
        ),
      ),
    );
  }


  bool validarEmail(String email) {
    // TODO: Implementar validarEmail
    print('validarEmail ejecutado');
  }

  void actualizarDatos(String nombre, String telefono) {
    // TODO: Implementar actualizarDatos
    print('actualizarDatos ejecutado');
  }

  List obtenerHistorialCompras() {
    // TODO: Implementar obtenerHistorialCompras
    print('obtenerHistorialCompras ejecutado');
  }

}
