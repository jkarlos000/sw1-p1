import 'package:flutter/material.dart';

class DetalleVentaScreen extends StatelessWidget {

  final int id;
  final int cantidad;
  final double precioUnitario;
  final double subtotal;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('DetalleVenta'),
        backgroundColor: Color(0xFF2196F3),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('id (int)'),
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('cantidad (int)'),
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('precioUnitario (double)'),
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('subtotal (double)'),
            ),
            SizedBox(height: 16),
            TextField(
              controller: idController,
              decoration: InputDecoration(
                labelText: 'Id',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: cantidadController,
              decoration: InputDecoration(
                labelText: 'Cantidad',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: precioUnitarioController,
              decoration: InputDecoration(
                labelText: 'PrecioUnitario',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: subtotalController,
              decoration: InputDecoration(
                labelText: 'Subtotal',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: calcularSubtotal,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('CALCULARSUBTOTAL', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: actualizarCantidad,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('ACTUALIZARCANTIDAD', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: validarCantidad,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('VALIDARCANTIDAD', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16)
          ],
        ),
      ),
    );
  }


  double calcularSubtotal() {
    // TODO: Implementar calcularSubtotal
    print('calcularSubtotal ejecutado');
  }

  void actualizarCantidad(int nuevaCantidad) {
    // TODO: Implementar actualizarCantidad
    print('actualizarCantidad ejecutado');
  }

  bool validarCantidad(int cantidad) {
    // TODO: Implementar validarCantidad
    print('validarCantidad ejecutado');
  }

}
