import 'package:flutter/material.dart';

class EmpleadoScreen extends StatelessWidget {

  final int id;
  final String nombre;
  final String cargo;
  final DateTime fechaIngreso;
  final double salario;

  final TextEditingController nombreController = TextEditingController();
  final TextEditingController cargoController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Empleado'),
        backgroundColor: Color(0xFF2196F3),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: nombreController,
              decoration: InputDecoration(
                labelText: 'Nombre',
                hintText: 'Ingrese nombre (String)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: cargoController,
              decoration: InputDecoration(
                labelText: 'Cargo',
                hintText: 'Ingrese cargo (String)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('id (int)'),
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('fechaIngreso (DateTime)'),
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('salario (double)'),
            ),
            SizedBox(height: 16),
            TextField(
              controller: idController,
              decoration: InputDecoration(
                labelText: 'Id',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: nombreController,
              decoration: InputDecoration(
                labelText: 'Nombre',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: cargoController,
              decoration: InputDecoration(
                labelText: 'Cargo',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: fechaIngresoController,
              decoration: InputDecoration(
                labelText: 'FechaIngreso',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: salarioController,
              decoration: InputDecoration(
                labelText: 'Salario',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: procesarVenta,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('PROCESARVENTA', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: consultarArticulo,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('CONSULTARARTICULO', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: generarReporte,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('GENERARREPORTE', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16)
          ],
        ),
      ),
    );
  }


  void procesarVenta(Venta venta) {
    // TODO: Implementar procesarVenta
    print('procesarVenta ejecutado');
  }

  Articulo consultarArticulo(int id) {
    // TODO: Implementar consultarArticulo
    print('consultarArticulo ejecutado');
  }

  String generarReporte(DateTime fechaInicio, DateTime fechaFin) {
    // TODO: Implementar generarReporte
    print('generarReporte ejecutado');
  }

}
