import 'package:flutter/material.dart';

class VentaScreen extends StatelessWidget {

  final int id;
  final DateTime fecha;
  final double total;
  final String estado;
  final String metodoPago;

  final TextEditingController estadoController = TextEditingController();
  final TextEditingController metodoPagoController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Venta'),
        backgroundColor: Color(0xFF2196F3),
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: estadoController,
              decoration: InputDecoration(
                labelText: 'Estado',
                hintText: 'Ingrese estado (String)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: metodoPagoController,
              decoration: InputDecoration(
                labelText: 'MetodoPago',
                hintText: 'Ingrese metodopago (String)',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('id (int)'),
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('fecha (DateTime)'),
            ),
            SizedBox(height: 16),
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey[300]!),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('total (double)'),
            ),
            SizedBox(height: 16),
            TextField(
              controller: idController,
              decoration: InputDecoration(
                labelText: 'Id',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: fechaController,
              decoration: InputDecoration(
                labelText: 'Fecha',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: totalController,
              decoration: InputDecoration(
                labelText: 'Total',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: estadoController,
              decoration: InputDecoration(
                labelText: 'Estado',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: metodoPagoController,
              decoration: InputDecoration(
                labelText: 'MetodoPago',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: calcularTotal,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('CALCULARTOTAL', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: agregarDetalle,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('AGREGARDETALLE', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: confirmarVenta,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('CONFIRMARVENTA', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: cancelarVenta,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('CANCELARVENTA', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: aplicarDescuentos,
              style: ElevatedButton.styleFrom(
                
              ),
              child: Text('APLICARDESCUENTOS', style: TextStyle(fontSize: 16)),
            ),
            SizedBox(height: 16)
          ],
        ),
      ),
    );
  }


  double calcularTotal() {
    // TODO: Implementar calcularTotal
    print('calcularTotal ejecutado');
  }

  void agregarDetalle(DetalleVenta detalle) {
    // TODO: Implementar agregarDetalle
    print('agregarDetalle ejecutado');
  }

  void confirmarVenta() {
    // TODO: Implementar confirmarVenta
    print('confirmarVenta ejecutado');
  }

  void cancelarVenta() {
    // TODO: Implementar cancelarVenta
    print('cancelarVenta ejecutado');
  }

  double aplicarDescuentos() {
    // TODO: Implementar aplicarDescuentos
    print('aplicarDescuentos ejecutado');
  }

}
