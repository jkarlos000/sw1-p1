import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'screens/screen.dart';
import 'screens/screen.dart';
import 'screens/screen.dart';
import 'screens/screen.dart';
import 'screens/screen.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Mockup',
      theme: AppTheme.lightTheme,
      home: const Screen(),
      routes: {
        '/screen': (context) => const Screen(),
        '/screen': (context) => const Screen(),
        '/screen': (context) => const Screen(),
        '/screen': (context) => const Screen(),
        '/screen': (context) => const Screen(),
      },
    );
  }
}
